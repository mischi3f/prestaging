Configuration IIS
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
      DependsOn = "[WindowsFeature]IIS"
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
        DependsOn = "[WindowsFeature]ASP"
    }
     Registry TimedWaitDelay {
       KEY = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
       Valuename = "TcpTimedWaitDelay"
       ValueType = "DWORD"
       ValueData = "30"
    DependsOn = "[WindowsFeature]WebServerManagementConsole"
       }
     Registry MaxUserPort {
       KEY = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
       Valuename = "MaxUserPort"
       ValueType = "DWORD"
       ValueData = "65534"
    DependsOn = "[WindowsFeature]WebServerManagementConsole"
       }
    }
}