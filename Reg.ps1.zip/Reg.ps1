Configuration Registry
{
  param ($MachineName)

  Node $MachineName
  {
    Registry TimedWaitDelay {
       KEY = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
       Valuename = "TcpTimedWaitDelay"
       ValueType = "DWORD"
       ValueData = "30"
    }
     Registry MaxUserPort {
       KEY = "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
       Valuename = "MaxUserPort"
       ValueType = "DWORD"
       ValueData = "65534"
	}
  }
}